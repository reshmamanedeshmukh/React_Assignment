function Navbar() {
    return (
        <div>
            <h3 style={{ color: 'white' }}>Client Mangement System</h3>
        </div>
    )
}
export default Navbar;