const clientsData = [
    {
      id: 1,
      clientName: 'Slb',
      startDate: '18/8/2020',
      endDate: '12/12/2022',
      contactPersonClient: 'aaaclient',
      contactPersonYash: 'aaayash',
      status: 'active'
    },
    {
        id: 2,
        clientName: 'Merk',
        startDate: '2/3/2020',
        endDate: '12/12/2021',
        contactPersonClient: 'bbbclient',
        contactPersonYash: 'bbbyash',
        status: 'Inactive'
    },
    
   
   

   
  ];
  
  export { clientsData };
  