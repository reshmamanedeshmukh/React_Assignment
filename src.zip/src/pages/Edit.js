import React, { useState } from 'react'
import Swal from 'sweetalert2';

function Edit({ clients, selectedClient, setClients, setIsEditing }) {

    const id = selectedClient.id;

    const [clientName, setclientName] = useState(selectedClient.clientName);
    const [startDate, setstartDate] = useState(selectedClient.startDate);
    const [endDate, setendDate] = useState(selectedClient.endDate);
    const [contactPersonClient, setcontactPersonClient] = useState(selectedClient.contactPersonClient);
    const [contactPersonYash, setcontactPersonYash] = useState(selectedClient.contactPersonYash);
    const [status, setstatus] = useState(selectedClient.status);


    const handleUpdate = e => {
        e.preventDefault();

        if (!clientName || !startDate || !endDate || !contactPersonClient || !contactPersonYash || !status) {
            return Swal.fire({
                icon: 'error',
                title: 'Error!',
                text: 'All fields are required.',
                showConfirmButton: true
            });
        }

        const client = {
            id,
            clientName,
            startDate,
            endDate,
            contactPersonClient,
            contactPersonYash,
            status
        };

        for (let i = 0; i < clients.length; i++) {
            if (clients[i].id === id) {
                clients.splice(i, 1, client);
                break;
            }
        }

        setClients(clients);
        setIsEditing(false);

        Swal.fire({
            icon: 'success',
            title: 'Updated!',
            text: `${client.clientName} 's data has been updated.`,
            showConfirmButton: false,
            timer: 1500
        });
    };

    return (
        <div className="small-container">
            <form onSubmit={handleUpdate}>
                <h1>Edit Employee</h1>
                <label htmlFor="clientName">Client Name</label>
                <input
                    id="clientName"
                    type="text"
                    
                    name="clientName"
                    value={clientName}
                    onChange={e => setclientName(e.target.value)}
                />
                <label htmlFor="startDate">startDate</label>
                <input
                    id="date"
                    type="date"
                    name="date"
                    value={startDate}
                    onChange={e => setstartDate(e.target.value)}
                />
                <label htmlFor="endDate">EndDate</label>
                <input
                    id="date"
                    type="date"
                    name="date"
                    value={endDate}
                    onChange={e => setendDate(e.target.value)}
                />
                <label htmlFor="contactPersonClient">contactPersonClient</label>
                <input
                    id="contactPersonClient"
                    type="text"
                    name="contactPersonClient"
                    value={contactPersonClient}
                    onChange={e => setcontactPersonClient(e.target.value)}
                />
                <label htmlFor="contactPersonYash">contactPersonYash</label>
                <input
                    id="contactPersonYash"
                    type="text"
                    name="contactPersonYash"
                    value={contactPersonYash}
                    onChange={e => setcontactPersonYash(e.target.value)}
                />
                <label htmlFor="status">status</label>
                <input
                    id="status"
                    type="text"
                    name="status"
                    value={status}
                    onChange={e => setstatus(e.target.value)}
                />
                 <div style={{ marginTop: '30px' }}>
                    <input type="submit" value="Update" />
                    <input
                        style={{ marginLeft: '12px' }}
                        className="muted-button"
                        type="button"
                        value="Cancel"
                        onClick={() => setIsEditing(false)}
                    />
                </div>
            </form>
        </div>
    );
}

export default Edit