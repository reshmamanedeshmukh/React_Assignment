import logo from './logo.svg';
import { Routes, Route } from "react-router-dom";
import '../node_modules/bootstrap/dist/css/bootstrap.min.css';
import Home from "./pages/Home";
import Dashboard from "./pages/Dashboard";
import View from './pages/View';
import './App.css';

function App() {
  return (
    <div className="App">
      <Routes>
        <Route path="/" element={ <Home/> } />
        <Route path="Dashboard" element={ <Dashboard/> } />
        <Route path="/View" element={ <View/> } />
    
      </Routes>
    </div>
  );
}

export default App;
